
<div class="form-group">
    <h1>Registro de Proyecto</h1>
    <br>
    <label for="nombre">Nombre de Proyecto</label>
    <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Ingrese el nombre del proyecto" value="<?php echo e(old('nombre', $proyecto->nombre)); ?>">
    </div>
    <br>
    
    <div class="form-group">
    <label for="exampleInputPassword1">Fecha de Inicio de Proyecto</label>
    <input type="text" class="form-control" name="fechaInicio" id="fechaInicio" placeholder="Ingrese la fecha de inicio" value="<?php echo e(old('fechaInicio', $proyecto->fechaInicio)); ?>">
    </div>
    <br>

    <div class="form-group">
        <label for="exampleInputPassword1">Subtotal</label>
        <input type="number" class="form-control" name="subtotal" id="subtotal" placeholder="Ingrese el subtotal" step="0.01" value="<?php echo e(old('subtotal', $proyecto->subtotal)); ?>">
        </div>
        <br>

    <div class="form-group">
        <label for="exampleInputPassword1">Concepto</label>
        <input type="text" class="form-control" name="concepto" id="concepto" placeholder="Ingrese el concepto" value="<?php echo e(old('concepto', $proyecto->concepto)); ?>">
        </div>
        <br>

  

        <div class="form-group">
            <label for="exampleInputPassword1">Seleccione proveedor</label>
            <select class="form-control" name="proveedor_id" id="proveedor_id" placeholder="Seleccione el tipo de persona" value="<?php echo e(old('proveedor_id', $proyecto->proveedor_id)); ?>">
                
                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($proveedor->id); ?>><?php echo e($proveedor->razonSocial); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                



              </select>    

        </div>
            <br>

            <div class="form-group">
                <label for="exampleInputPassword1">Seleccione cliente</label>
                <select class="form-control" name="cliente_id" id="cliente_id" placeholder="Seleccione el tipo de persona" value="<?php echo e(old('cliente_id', $proyecto->cliente_id)); ?>">
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($cliente->id); ?>><?php echo e($cliente->razonSocial); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>    
            </div>
                <br>
            
        <div class="form-group">
            <label for="exampleInputPassword1">Comentarios adicionales</label>
            <textarea class="form-control" name="comentariosAdicionales" id="comentariosAdicionales"  placeholder="Ingrese comentarios adicionales" ><?php echo e(old('comentariosAdicionales', $proyecto->comentariosAdicionales)); ?></textarea>
            <br> 

        <button type="submit" value="Enviar" class="btn btn-primary">Crear</button>
    </div>
                                <?php /**PATH C:\laragon\www\proyectoinfo6\resources\views/dashboard/proyecto/_form.blade.php ENDPATH**/ ?>