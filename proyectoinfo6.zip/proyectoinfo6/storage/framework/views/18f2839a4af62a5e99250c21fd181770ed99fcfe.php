<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="">Proyectos</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">

        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(route('transaccion.index')); ?>">Home</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('proyecto.index')); ?>">Proyectos</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('entidad.index')); ?>">Entidades</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('transaccion.index')); ?>">Transacciones</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('user.index')); ?>">Usuarios</a>
        </li>


        <?php if(auth()->guard()->check()): ?>
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                <?php echo e(Auth::user()->name); ?>

            </a>

            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
              
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
          </li>            
        <?php endif; ?>

        



        
    </div>
  </nav><?php /**PATH C:\laragon\www\proyectoinfo6\resources\views/fragments/nav-bar.blade.php ENDPATH**/ ?>