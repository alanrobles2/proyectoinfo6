
<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

</div>

<?php endif; ?><?php /**PATH C:\laragon\www\proyectoinfo6\resources\views/fragments/sesion.blade.php ENDPATH**/ ?>