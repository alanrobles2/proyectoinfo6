<?php $__env->startSection('content'); ?>

<?php echo $__env->make('fragments.validation-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('fragments.sesion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form method="POST" action="<?php echo e(route("entidad.store")); ?>">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('dashboard.entidad._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectoinfo6\resources\views/dashboard/entidad/create.blade.php ENDPATH**/ ?>