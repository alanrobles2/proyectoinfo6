<?php $__env->startSection('content'); ?>
<h1>Entidades</h1>

<a href="<?php echo e(route('entidad.create')); ?>" class="btn btn-success">Registrar Entidad</a>


<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Razon Social</th>
      <th scope="col">Tipo</th>
      <th scope="col">Persona</th>
      <th scope="col">RFC</th>
      <th scope="col">Domicilio</th>
      <th scope="col">Email</th>
      <th scope="col">Telefono</th>
      <th scope="col" colspan="2">Opciones</th>
      
    </tr>
  </thead>
  <tbody>
    
    <?php $__currentLoopData = $entidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entidades): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
      <th scope="row"><?php echo e($entidades->id); ?></th>
    
        <td><?php echo e($entidades->razonSocial); ?></td>
        <td><?php echo e($entidades->persona_id); ?></td>
        <td><?php echo e($entidades->persona); ?></td>
        <td><?php echo e($entidades->RFC); ?></td>
        <td><?php echo e($entidades->domicilio); ?></td>
        <td><?php echo e($entidades->email); ?></td>
        <td><?php echo e($entidades->telefono); ?></td>
        <td>
          <a href="<?php echo e(route('entidad.edit', $entidades->id)); ?>" class="btn btn-secondary">Edit</a>
        </td>
        <td>
          <button data-bs-toggle="modal" data-bs-target="#deleteModal" data-bs-id="<?php echo e($entidades->id); ?>" type="submit" class="btn btn-danger">Delete</button>
        </td>

      </tr>  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

  </tbody>
</table>

<div class="mt-3"><?php echo e($entidad->links()); ?></div>

<div class="modal fade" id="deleteModal" role="dialog" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>¿Estás seguro de borrar el registro seleccionado?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <form id="formDelete" action="<?php echo e(route('entidad.destroy', 0)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field("DELETE"); ?>
          <button class="btn btn-danger" type="submit">Eliminar</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
 
  var deleteModal = document.getElementById('deleteModal')
  deleteModal.addEventListener('show.bs.modal', function (event) {
    // Button that triggered the modal
    var button = event.relatedTarget
    // Extract info from data-bs-* attributes
    var id = button.getAttribute('data-bs-id')
    // If necessary, you could initiate an AJAX request here
    // and then do the updating in a callback.
    // Update the modal's content.
    var modalTitle = deleteModal.querySelector('.modal-nombre')
    var action = formDelete.getAttribute('action').slice(0, -1) + id;
    //action += id;  
    console.log(action);
    formDelete.setAttribute('action', action);                                    
    //console.log(formDelete.getAttribute('action'));
    modalTitle.textContent = 'Entidad: ' + id;
    //modalBodyInput.value = recipient
  })
</script>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proyectoinfo6\resources\views/dashboard/entidad/entidad.blade.php ENDPATH**/ ?>